import { useCreateTeamMemberAxios } from "@/api/queries/teamAxios"

const useTeamFeatureService = () => {
  const {mutate , isPending} = useCreateTeamMemberAxios();

  // function create

  return{

  }
}

