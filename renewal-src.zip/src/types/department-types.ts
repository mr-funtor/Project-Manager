export type DepartmentResponse = {
  id: number,
  name: string,
}

export type CreateDepartmentPayloadType = {
  name: string,
}