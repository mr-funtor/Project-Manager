export type LoginPayloadType ={
  username: string,
  password: string,
  token: string
}

export type loginInitialValuesType ={
  email: string,
  password: string,
}
