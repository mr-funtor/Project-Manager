const allRoles = {
  Initiator: "Inputter",
  Validator : "Validator",
  BranchAuthorizer : "AuthorizerCCS",
  CCCRequester: "Requester",
  PPSAuthoriser: "AuthorizerCCC",
  NidaReviewer: "NidalReviewer"
};

export {
  allRoles,
}